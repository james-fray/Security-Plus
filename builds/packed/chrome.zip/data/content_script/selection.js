/* globals background */
'use strict';

var match = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;

document.addEventListener('mouseup', function () {
  var selected = window.getSelection().toString();
  if (selected && match.test(selected)) {
    background.send('valid-link', selected);
  }
});
